<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <?php echo '<p>Hello World! Here are all of my Links! Michael Brodsky, Peroid:2</p>'; ?> 
    <ul>
      <li><a href="index.html">index.html</a></li></br>
      <li><a href="Brodsky_AboutMe.html"> AboutMe.html</a></li></br>
      <li><a href="Brodsky_Projects.html"> Projects.html</a></li></br>
      <li><a href="Brodsky_Resume.html"> Resume.html</a></li></br>
      <li><a href="Brodsky_ContactMe.html">ContactMe.html</a></li></br>
    <ul>
    <p>(If image's width is tight, try realoading)</p>
  </body>
</html>